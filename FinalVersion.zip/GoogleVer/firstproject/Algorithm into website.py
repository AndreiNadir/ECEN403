
import pandas as pd
import math
from sklearn import preprocessing, svm, model_selection
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
import pickle
import csv
from random import randint

# file = open('Testing_And_Training_Data.csv')
# type(file)
# csvreader = csv.reader(file)
# header = []
# header = next(csvreader)
# rows = []
# for row in csvreader:
#     rows.append(row)
# file.close()
#
# data = rows
# df = pd.DataFrame(data, columns=header)
# df.fillna(-99999, inplace=True)
#
# forecast_out = int(math.ceil(.1*len(df)))  # how many predictions out is predicted
#
# df.dropna(inplace=True)  # when dropping na the most recent date 2018-03-27 is dropped until forecast out
#
#
# feature_cols = ['U_Priority', 'G_Priority', 'U_Large_MP4', 'G_Large_MP4', 'U_Small_MP4', 'G_Small_MP4', 'U_TXT',
#                 'G_TXT',  'U_IMG', 'G_IMG']
# X = df[feature_cols]
# Y = df.Output
# x_train, x_test, y_train, y_test = model_selection.train_test_split(X, Y, test_size=.01, random_state=randint(0, 999))

pickle_in = open('Websiteregression.pickle', 'rb')
clf = pickle.load(pickle_in)
# clf = LogisticRegression(n_jobs=-1)

#clf.fit(x_train, y_train)  # classifier is fit using trains
y_pred = clf.predict([[2,14,2,10,4,12,5,11,7,14]])

#print('x_test: ', x_test)
print('y_prediction: ', y_pred)

#accuracy = clf.score(x_test, y_test)

#print('\n accuracy: ', accuracy, '\n predictions forecasted:  ', forecast_out)

