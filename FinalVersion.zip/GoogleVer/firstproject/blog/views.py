from django.shortcuts import render
from .forms import *
from .templates import *
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import (
    ListView,
    DetailView,
    CreateView,
    UpdateView,
    DeleteView
)
from .models import Post
from users.models import Global
from google.cloud import storage
from users.models import Profile
def home(request):
    context = {
        'posts': Post.objects.all()
    }
    return render(request, 'blog/home.html', context)

class downloadFile(ListView):
    model = Post
    template_name = 'blog/download_form.html'
    storage_client = storage.Client("My First Project")
    # Create a bucket object for our bucket
    bucket = storage_client.get_bucket('ecen403images')
    # Create a blob object from the filepath
    blob = bucket.blob("images/thumb.jpg")
    # Download the file to a destination
    #blob.download_to_filename(r'C:\Users\theun\PycharmProjects\GoogleVer\firstproject\media\images\ham.jpg')


class PostListView(ListView):
    model = Post
    template_name = 'blog/home.html'  # <app>/<model>_<viewtype>.html
    context_object_name = 'posts'
    ordering = ['-date_posted']


class PostDetailView(DetailView):
    model = Post
    #Global.endtag = Post.objects.all().last().image

class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    fields = ['title', 'Priority_Upload', 'image']
    def form_valid(self, form):
        form.instance.author = self.request.user
        form.save()
        return super().form_valid(form)


class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['title', 'Priority_Upload', 'image']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    success_url = '/'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False

def landing(request):
    return render(request, 'blog/landing.html', {'title': 'About'})

