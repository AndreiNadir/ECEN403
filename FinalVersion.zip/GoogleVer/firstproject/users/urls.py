from django.urls import path
from . import views
from .views import PostDetailView, PostCreateView, PostUpdateView, PostDeleteView
urlpatterns = [
    #Path sets up a path command. First argument is the tag its looking for.
    #second argument is where it goes to get the http code, and 3rd is name


]

