from django.db import models
from django.contrib.auth.models import User
class Global(models.Model):

    globalimg = 0
    globalvid = 0
    globalbvid = 0
    globaltext = 0
    globalprio = 0
    endtag = ""
    counter = 1
