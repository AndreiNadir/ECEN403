from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.urls import reverse
import os
from users.classes import Global

# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    #image = models.ImageField(default='default.png', upload_to='profile_pics')
    imguploads = models.IntegerField(default=0)
    viduploads = models.IntegerField(default=0)
    bviduploads = models.IntegerField(default=0)
    textuploads = models.IntegerField(default=0)
    priouploads = models.IntegerField(default=0)
    algonum = 0
    location = ""

    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio
    array = [priouploads, gprio, bviduploads, gbvid, viduploads, gvid, textuploads, gtxt, imguploads, gimg]
    #print("Array", array)
    def __str__(self):
        return f'{self.user.username} Profile'


