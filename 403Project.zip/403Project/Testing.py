import matplotlib.pyplot as plt
import pandas as pd
import math
import quandl
import numpy as np
import sklearn.linear_model
from sklearn import preprocessing, svm, model_selection
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
import datetime
from matplotlib import style
import pickle
import csv
from random import randint

file = open('Testing_And_Training_Data.csv')
type(file)
csvreader = csv.reader(file)
header = []
header = next(csvreader)
rows = []
# print('starting for loop \n')
for row in csvreader:
    rows.append(row)
file.close()
# print(header, '\n', rows)

data = rows
df = pd.DataFrame(data, columns=header)
df.fillna(-99999, inplace=True)


# forecast_col = 'Output'  # creating column to be predicted/forecasted
forecast_out = int(math.ceil(.1*len(df)))  # how many predictions out is predicted

df.dropna(inplace=True)  # when dropping na the most recent date 2018-03-27 is dropped until forecast out


feature_cols = ['U_Priority', 'G_Priority', 'U_Large_MP4', 'G_Large_MP4', 'U_Small_MP4', 'G_Small_MP4', 'U_TXT',
                'G_TXT',  'U_JPEG', 'G_JPEG', 'U_PNG', 'G_PNG']
X = df[feature_cols]
Y = df.Output
x_train, x_test, y_train, y_test = model_selection.train_test_split(X, Y, test_size=.2, random_state=randint(0, 999))

# print('x_train:', x_train)
# print('\n y_train: \n', y_train)
# print('\n x_test:', x_test)
# print('\n y_test:', y_test)
clf = LogisticRegression(n_jobs=-1)
# clf = svm.SVR(kernel='linear')  # classifier created as linear regression n_jobs = -1 uses all CPUs
# clf = LinearRegression(n_jobs=-1)

clf.fit(x_train, y_train)  # classifier is fit using trains
y_pred = clf.predict(x_test)

print('x_test: ', x_test)
print('y_prediction: ', y_pred)

accuracy = clf.score(x_test, y_test)

print('\n accuracy: ', accuracy, '\n predictions forecasted:  ', forecast_out)

# df['Forecast'] = np.nan
# print(df)

# style.use('ggplot')
# quandl.ApiConfig.api_key = '-ix4suWa3RC35MGP7mpr'

# df = quandl.get('WIKI/GOOGL')  # pulling stock prices from quandl
# df = df[['Adj. Open', 'Adj. High', 'Adj. Low', 'Adj. Close', 'Adj. Volume']]  # creating dataframe labels from quandl
# df['HL_PCT'] = (df['Adj. High'] - df['Adj. Low']) / df['Adj. Close'] * 100.00  # calculating the high - lox percent
# df['PCT_change'] = (df['Adj. Close'] - df['Adj. Open']) / df['Adj. Open'] * 100.00  # calculating daily percent change
#
# df = df[['Adj. Close', 'HL_PCT', 'PCT_change', 'Adj. Volume']] # defining new dataframe with new columns we care about
#
# # print(df.head())  # prints last values on the dataframe
#
# forecast_col = 'Adj. Close'  # creating column to be predicted/forecasted
# df.fillna(-99999, inplace=True)  # in the event of missing data fill it with -99999
#
# forecast_out = int(math.ceil(.01*len(df)))  # how many days out is predicted
# # print("HERE IS FORECAST OUT HERE IS IT: ", forecast_out)  # printing the forecast
#
#
# df['label'] = df[forecast_col].shift(-forecast_out)  # shifting the data up by the length of forecast out
# print("Here is DF.tail: \n", df.tail()) # printing the head of hte new dataframe
#
#
# x = np.array(df.drop(['label'], 1))  # features is all data except label column
# print("HERE IS X BEFORE PREPROCESSING: \n", x)
# x = preprocessing.scale(x)
# print("HERE IS X AFTER PREPROCESSING: \n", x)
# x_lately = x[-forecast_out:]  # what is being predicted
# print("HERE IS X_LATELY HERE IT IS: \n", x_lately)
# x = x[:-forecast_out]  # x is
# print("HERE IS X HERE IS IT: \n", x)
#
#
# df.dropna(inplace=True)  # when dropping na the most recent date 2018-03-27 is dropped until forecast out
#
# print("Here is DF: \n", df)
#
# y = np.array(df['label'])  # y is array of label column
# print("HERE IS Y: \n", y)
#
#
# # takes data and shuffles it and outputs it into x/y train and x/y test ( keeps x and y connected)
# x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, test_size=.2)
#
# clf = LinearRegression(n_jobs=-1)  # svm.SVR() # classifier created as linear regression n_jobs = -1 uses all CPUs
# clf.fit(x_train, y_train)  # classifier is fit using trains
#
#
# # creating the pickle to carry over hte classifier so it does not have to be remade every time
# # with open('linearregression.pickle','wb') as f:
# #    pickle.dump(clf, f)
# #
# # pickle_in = open('linearregression.pickle', 'rb')
# # clf = pickle.load(pickle_in)
#
# accuracy = clf.score(x_test, y_test)  # calculating the accuracy based on tests
#
#
# forecast_set = clf.predict(x_lately)
# print('forecasted set: \n', forecast_set, '\n accuracy: ', accuracy, '\n days forecasted:  ', forecast_out)
#
# df['Forecast'] = np.nan
#
# last_date = df.iloc[-1].name  # gets the last date of the data ex: 2006-08-04
# last_unix = last_date.timestamp()  # converting the last date into unix format
# one_day = 86400  # setting 1 day equal to 86400 seconds
# next_unix = last_unix + one_day  # defining what the next day is going to be
#
#
# for i in forecast_set:
#     next_date = datetime.datetime.fromtimestamp(next_unix)  # normal date of next_unix is next_date
#     # print(next_date)
#     next_unix += one_day  # adding a day to next_unix
#     df.loc[next_date] = [np.nan for _ in range(len(df.columns)-1)] + [i]
#
# # print(df.tail())
# df['Adj. Close'].plot()
# df['Forecast'].plot()
# plt.legend(loc=4)
# plt.xlabel('Date')
# plt.ylabel('Price')
# plt.show()
# # print(df.head())
# # print(df.tail())


# cross_validation
# use array of dataset split into 5 parts with each one
