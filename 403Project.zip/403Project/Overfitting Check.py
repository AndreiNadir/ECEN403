import pandas as pd
import math
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import svm
import csv
# real_world_Date.csv
file = open('Testing_And_Training_Data.csv')
type(file)
csvreader = csv.reader(file)
header = next(csvreader)
rows = []

for row in csvreader:
    rows.append(row)
file.close()

overfit_len = int(len(rows)/5)
rows0 = []
rows1 = []
rows2 = []
rows3 = []
rows4 = []
i = 0
while i < overfit_len:
    rows0.append(rows[i])
    rows1.append(rows[i + overfit_len])
    rows2.append(rows[i + overfit_len * 2])
    rows3.append(rows[i + overfit_len * 3])
    rows4.append(rows[i + overfit_len * 4])
    i += 1

# print("rows at 0: ", rows0)
# print("rows at 1: ", rows1)
# print("rows at 2: ", rows2)
# print("rows at 3: ", rows3)
# print("rows at 4: ", rows4)

# testing rows0
data0 = rows0
df0 = pd.DataFrame(data0, columns=header)
df0.fillna(-99999, inplace=True)

data_not_0 = rows1 + rows2 + rows3 + rows4
df_not_0 = pd.DataFrame(data_not_0, columns=header)
df_not_0.fillna(-99999, inplace=True)

# testing rows1
data1 = rows1
df1 = pd.DataFrame(data1, columns=header)
df1.fillna(-99999, inplace=True)

data_not_1 = rows0 + rows2 + rows3 + rows4
df_not_1 = pd.DataFrame(data_not_1, columns=header)
df_not_1.fillna(-99999, inplace=True)

# testing rows2
data2 = rows2
df2 = pd.DataFrame(data2, columns=header)
df2.fillna(-99999, inplace=True)

data_not_2 = rows0 + rows1 + rows3 + rows4
df_not_2 = pd.DataFrame(data_not_2, columns=header)
df_not_2.fillna(-99999, inplace=True)

# testing rows3
data3 = rows3
df3 = pd.DataFrame(data3, columns=header)
df3.fillna(-99999, inplace=True)

data_not_3 = rows0 + rows1 + rows2 + rows4
df_not_3 = pd.DataFrame(data_not_3, columns=header)
df_not_3.fillna(-99999, inplace=True)

# testing rows4
data4 = rows4
df4 = pd.DataFrame(data4, columns=header)
df4.fillna(-99999, inplace=True)

data_not_4 = rows0 + rows1 + rows2 + rows3
df_not_4 = pd.DataFrame(data_not_4, columns=header)
df_not_4.fillna(-99999, inplace=True)

forecast_col = 'Output'  # creating column to be predicted/forecasted
forecast_out = int(math.ceil(len(df0)))  # how many predictions out is predicted

df0.dropna(inplace=True)  # when dropping na the most recent date 2018-03-27 is dropped until forecast out
df1.dropna(inplace=True)
df2.dropna(inplace=True)
df3.dropna(inplace=True)
df4.dropna(inplace=True)

feature_cols = ['U_Priority', 'G_Priority', 'U_Large_MP4', 'G_Large_MP4', 'U_Small_MP4', 'G_Small_MP4', 'U_TXT',
                'G_TXT', 'U_JPEG', 'G_JPEG', 'U_PNG', 'G_PNG']

# creating test and train for rows0
x_test0 = df0[feature_cols]
y_test0 = df0.Output
x_train0 = df_not_0[feature_cols]
y_train0 = df_not_0.Output

# creating test and train for rows1
x_test1 = df1[feature_cols]
y_test1 = df1.Output
x_train1 = df_not_1[feature_cols]
y_train1 = df_not_1.Output

# creating test and train for rows2
x_test2 = df2[feature_cols]
y_test2 = df2.Output
x_train2 = df_not_2[feature_cols]
y_train2 = df_not_2.Output

# creating test and train for rows3
x_test3 = df3[feature_cols]
y_test3 = df3.Output
x_train3 = df_not_3[feature_cols]
y_train3 = df_not_3.Output

# creating test and train for rows4
x_test4 = df4[feature_cols]
y_test4 = df4.Output
x_train4 = df_not_4[feature_cols]
y_train4 = df_not_4.Output

# print('\n \n x_train: \n ', x_train0)
# print('\n \n y_train: \n ', y_train0)
# print('\n \n x_test: \n ', x_test0)
# print('\n \n y_test: \n ', y_test0)

clf0 = LogisticRegression(n_jobs=-1)
clf1 = LogisticRegression(n_jobs=-1)
clf2 = LogisticRegression(n_jobs=-1)
clf3 = LogisticRegression(n_jobs=-1)
clf4 = LogisticRegression(n_jobs=-1)

#clf0 = svm.SVC(kernel = 'poly')
#clf1 = svm.SVC(kernel = 'poly')
#clf2 = svm.SVC(kernel = 'poly')
#clf3 = svm.SVC(kernel = 'poly')
#clf4 = svm.SVC(kernel = 'poly')


clf0.fit(x_train0, y_train0)  # classifier is fit using trains
clf1.fit(x_train1, y_train1)
clf2.fit(x_train2, y_train2)
clf3.fit(x_train3, y_train3)
clf4.fit(x_train4, y_train4)

# y_pred0 = clf0.predict(x_test0)
# print('x_test: ', x_test)
# print('y_prediction: ', y_pred)

accuracy0 = clf0.score(x_test0, y_test0) * 100
accuracy1 = clf1.score(x_test1, y_test1) * 100
accuracy2 = clf2.score(x_test2, y_test2) * 100
accuracy3 = clf3.score(x_test3, y_test3) * 100
accuracy4 = clf4.score(x_test4, y_test4) * 100

print('predictions: ', forecast_out)
print('\n accuracy0: ', accuracy0, '\n', 'accuracy1: ', accuracy1, '\n', 'accuracy2: ', accuracy2,
      '\n', 'accuracy3: ', accuracy3, '\n', 'accuracy4: ', accuracy4)
