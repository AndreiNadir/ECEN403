import csv
from random import randint

# generate some integers
userID = []
user_priority = []
user_large_MP4 = []
user_small_MP4 = []
user_TXT = []
user_JPEG = []
user_PNG = []

global_priority = []
global_large_MP4 = []
global_small_MP4 = []
global_TXT = []
global_JPEG = []
global_PNG = []

output = 0
priority = 0
PNG = 0
Jpeg = 0
TXT = 0
L_MP4 = 0
S_MP4 = 0

global_weight = .2  # amount of weight given to a global upload in calculating the output
user_weight = .8  # amount of weight given to a user upload in calculating the output

Features = ['U_Priority', 'G_Priority', 'U_Large_MP4', 'G_Large_MP4',
            'U_Small_MP4', 'G_Small_MP4', 'U_TXT', 'G_TXT', 'U_JPEG', 'G_JPEG',
            'U_PNG', 'G_PNG', 'Output']

# Features = ['U_Priority', 'U_Large_MP4', 'U_Small_MP4', 'U_TXT', 'U_JPEG', 'U_PNG', 'Output']
filename = "Testing_And_Training_Data.csv"
user_upload = [[]]
with open(filename, 'w', newline='') as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(Features)
    for i in range(5000):
        user_value = randint(1, 10)  # creating the random values
        userID.append(user_value)

        user_priority.append(randint(0, 7))
        user_large_MP4.append(randint(0, 7))
        user_small_MP4.append(randint(0, 7))
        user_TXT.append(randint(0, 7))
        user_JPEG.append(randint(0, 7))
        user_PNG.append(randint(0, 7))

        global_priority.append(randint(0, 14))
        global_large_MP4.append(randint(0, 14))
        global_small_MP4.append(randint(0, 14))
        global_TXT.append(randint(0, 14))
        global_JPEG.append(randint(0, 14))
        global_PNG.append(randint(0, 14))

        # weighting the features with the user and global uploads
        priority = (global_weight * global_priority[i]) + (user_weight * user_priority[i])
        PNG = (global_weight * global_PNG[i]) + (user_weight * user_PNG[i])
        Jpeg = (global_weight * global_JPEG[i]) + (user_weight * user_JPEG[i])
        TXT = (global_weight * global_TXT[i]) + (user_weight * user_TXT[i])
        L_MP4 = (global_weight * global_large_MP4[i]) + (user_weight * user_large_MP4[i])
        S_MP4 = (global_weight * global_small_MP4[i]) + (user_weight * user_small_MP4[i])

        outputs = [priority, L_MP4, S_MP4, TXT, Jpeg, PNG]
        output = (outputs.index(max(outputs)) + 1)

        # writing to the csv file
        csvwriter.writerow([user_priority[i], global_priority[i], user_large_MP4[i], global_large_MP4[i],
                           user_small_MP4[i], global_small_MP4[i], user_TXT[i], global_TXT[i],
                           user_JPEG[i], global_JPEG[i], user_PNG[i], global_PNG[i], output])
        # csvwriter.writerow([user_priority[i], user_large_MP4[i], user_small_MP4[i], user_TXT[i], user_JPEG[i],
        # user_PNG[i], output])
        # print(user_value)
