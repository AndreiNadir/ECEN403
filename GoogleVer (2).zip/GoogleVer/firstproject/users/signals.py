from django.db.models.signals import *
from django.contrib.auth.signals import user_logged_in
from django.contrib.auth.models import User
from django.dispatch import receiver
from .models import Profile, Global
import pickle
import pandas as pd
import math
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
import csv
from random import randint
from blog.models import Post
from users.models import Global
# when a user is saved, send this signal to create profile.
import os
import shutil


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=Post)
def filecheck(sender, **kwargs):
    Global.endtag = Post.objects.all().last().image
    temp = Global.endtag
    if str(temp).endswith(".jpeg") or str(temp).endswith(".jpg") or str(temp).endswith(".png"):
        Profile.imguploads = Profile.imguploads + 0.5
        Global.globalimg = Global.globalimg + 0.5
    if str(temp).endswith(".txt"):
        Profile.textuploads = Profile.textuploads + 0.5
        Global.globaltext = Global.globaltext + 0.5
    if str(temp).endswith(".mov") or str(temp).endswith(".mp4"):
        Profile.viduploads = Profile.viduploads + 0.5
        Global.globalvid = Global.globalvid + 0.5
    if str(temp).endswith(".mov") or str(temp).endswith(".mp4"):
        Profile.bviduploads = Profile.bviduploads + 0.5
        Global.globalbvid = Global.globalbvid + 0.5
    print(Profile.imguploads)

@receiver(post_save, sender=Post)
def post_login1(sender, **kwargs):
    img = Profile.imguploads
    vid = Profile.viduploads
    bvid = Profile.bviduploads
    txt = Profile.textuploads
    prio = Profile.priouploads

    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio
    array = [prio, gprio, bvid, gbvid, vid, gvid, txt, gtxt, img, gimg]
    testarr = [4, 9, 7, 3, 2, 5, 6, 12, 7, 10]

    #########

    pickle_in = open('Websiteregression.pickle', 'rb')
    clf = pickle.load(pickle_in)
    # clf = LogisticRegression(n_jobs=-1)

    # clf.fit(x_train, y_train)  # classifier is fit using trains
    y_pred = clf.predict([array])

    # print('x_test: ', x_test)
    print("PREDICTION: ", y_pred)
    Profile.algonum = int(y_pred[0])
    if Profile.algonum == 1:
        Profile.location = 'priority/'
    if Profile.algonum == 2:
        Profile.location = 'large_video/'
    if Profile.algonum == 3:
        Profile.location = 'video/'
    if Profile.algonum == 4:
        Profile.location = 'text/'
    if Profile.algonum == 5:
        Profile.location = 'images/'

@receiver(post_save, sender=User)
def save_profile(sender, instance, **kwargs):
    instance.profile.save()

@receiver(post_save, sender=Post)
def error_checker(sender, **kwargs):
    check = Post.objects.all().last().image
    print("CHECK IS THIS", check)
    print("Profile.location is", Profile.algonum)
    if (not str(check).endswith(".txt")) and Profile.algonum == 4:
        print("INCORRECTLY SAVED text")
       # if str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(".png"):
         #   shutil.move("ecen403images/"+str(check), "ecen403images/images/testfile.txt")
       # if str(check).endswith(".txt"):
       # if str(check).endswith(".mov") or str(check).endswith(".mp4"):
       # if str(check).endswith(".mov") or str(check).endswith(".mp4"):
    if (str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(".png")) and Profile.algonum != 5:
        print("INCORRECTLY SAVED image")
    if (str(check).endswith(".mov") or str(check).endswith(".mp4")) and Profile.algonum != 3:
        print("INCORRECTLY SAVED")
    if (str(check).endswith(".mov") or str(check).endswith(".mp4")) and Profile.algonum != 2:
        print("INCORRECTLY SAVED")
#@receiver(post_save, sender=User)
#def file_size(sender, **kwargs): # add this to some file where you can import it from
 #   limit = 104857600
  #  if Post > limit:
   #     print("FILE IS TOO LARGE")
# This will check if the user is logged in
@receiver(user_logged_in)
def post_login(sender, **kwargs):
    img = Profile.imguploads
    vid = Profile.viduploads
    bvid = Profile.bviduploads
    txt = Profile.textuploads
    prio = Profile.priouploads

    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio
    array = [prio, gprio, bvid, gbvid, vid, gvid, txt, gtxt, img, gimg]
    testarr = [4, 9, 7, 3, 2, 5, 6, 12, 7, 10]

    #########

    pickle_in = open('Websiteregression.pickle', 'rb')
    clf = pickle.load(pickle_in)
    # clf = LogisticRegression(n_jobs=-1)

    # clf.fit(x_train, y_train)  # classifier is fit using trains
    y_pred = clf.predict([array])

    # print('x_test: ', x_test)
    print('y_prediction: ', y_pred)
    Profile.algonum = int(y_pred[0])
    if Profile.algonum == 1:
        Profile.location = 'priority/'
    if Profile.algonum == 2:
        Profile.location = 'large_video/'
    if Profile.algonum == 3:
        Profile.location = 'video/'
    if Profile.algonum == 4:
        Profile.location = 'text/'
    if Profile.algonum == 5:
        Profile.location = 'images/'
    print(Profile.location)

    #####
