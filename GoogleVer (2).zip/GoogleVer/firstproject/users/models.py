from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.urls import reverse
import os


# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    image = models.ImageField(default='default.jpg', upload_to='profile_pics')
    imguploads = 0
    viduploads = 0
    bviduploads = 0
    textuploads = 0
    priouploads = 0
    algonum = 0
    location = ""

    def __str__(self):
        return f'{self.user.username} Profile'




class Global():
    globalimg = 0
    globalvid = 0
    globalbvid = 0
    globaltext = 0
    globalprio = 0
    endtag = ""
