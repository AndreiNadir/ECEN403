from django.db import models
from django.contrib.auth.models import User
class Global(models.Model):

    globalimg = 13
    globalvid = 7
    globalbvid = 5
    globaltext = 9
    globalprio = 11
    endtag = ""
    counter = 1
    RetrainCounter = 0