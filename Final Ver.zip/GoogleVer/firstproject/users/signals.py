from django.db.models.signals import *
from django.contrib.auth.signals import user_logged_in
from django.contrib.auth.models import User
from django.dispatch import receiver
from .models import Profile, Global
import pickle
from random import randint
import pandas as pd
import math
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
import csv
from random import randint
from blog.models import Post
from users.models import Profile
from users.classes import Global
# when a user is saved, send this signal to create profile.
import os
import shutil
import xlsxwriter
from google.cloud import storage
import csv

@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=Post)
def filecheck(sender, **kwargs):
    Global.endtag = Post.objects.all().last().image
    temp = str(Global.endtag)
    client = storage.Client()
    # Create a bucket object for our bucket
    bucket = client.get_bucket('ecen403images')
    # Create a blob object from the filepath
    blob = bucket.get_blob(temp)
    #print(" PATH PATH PATH", Post.objects.all().last().size)
    #Profile.array
    profile = Profile.objects.get(user=kwargs.get('instance').author)
    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio

    if str(temp).endswith(".jpeg") or str(temp).endswith(".jpg") or str(temp).endswith(".png") or str(temp).endswith(".PNG"):
        profile.imguploads+=1
        profile.save()
        #print("IMAGE UPLOADS: ", profile.imguploads)
        Global.globalimg = Global.globalimg + 0.5
    if str(temp).endswith(".txt"):
        profile.textuploads += 1
        profile.save()
        #print("Text UPLOADS: ", profile.textuploads)
        Global.globaltext = Global.globaltext + 0.5
    if (str(temp).endswith(".MOV") or str(temp).endswith(".mp4")) and (blob.size/1000000 < 10):
        profile.viduploads += 1
        profile.save()
        #print("VIDEO UPLOADS: ", profile.viduploads)
        Global.globalvid = Global.globalvid + 0.5
        # Checks if filesize is > 10 megabytes
    if (str(temp).endswith(".MOV") or str(temp).endswith(".mp4")) and (blob.size/1000000 >= 10):
        profile.bviduploads += 1
        profile.save()
        #print("IMAGE UPLOADS: ", profile.bviduploads)
        Global.globalbvid = Global.globalbvid + 0.5
    array = [profile.priouploads/2, gprio, profile.bviduploads/2, gbvid, profile.viduploads/2, gvid, profile.textuploads/2,
             gtxt, profile.imguploads/2, gimg]
@receiver(post_save, sender=Post)
def post_login1(sender, **kwargs):
    profile = Profile.objects.get(user=kwargs.get('instance').author)
    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio
    array = [math.floor(profile.priouploads/2), math.ceil(gprio), math.floor(profile.bviduploads/2), math.ceil(gbvid), math.floor(profile.viduploads/2), math.ceil(gvid), math.floor(profile.textuploads/2),
             math.ceil(gtxt), math.floor(profile.imguploads/2), math.ceil(gimg)]
    #array = [prio, gprio, bvid, gbvid, vid, gvid, txt, gtxt, img, gimg]
    #testarr = [4, 9, 7, 3, 2, 5, 6, 12, 7, 10]
    #print("Array:", array, "\n\n\n\n")
    #########
    #opening pickle
    pickle_in = open('Websiteregression.pickle', 'rb')
    clf = pickle.load(pickle_in)
    # clf = LogisticRegression(n_jobs=-1)

    # clf.fit(x_train, y_train)  # classifier is fit using trains
    y_pred = clf.predict([array])

    # print('x_test: ', x_test)
    array.append(int(y_pred[0]))
    filename = "Retraining_Data.csv"
    Features = ['U_Priority', 'G_Priority', 'U_LargeMP4', 'G_LargeMP4', 'U_SmallMP4', 'G_SmallMP4', 'U_TXT', 'G_TXT', 'U_IMG', 'G_IMG', 'Output']

    with open(filename, 'a', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        #csvwriter.writerow(Features)
        csvwriter.writerow(array)
    array.pop()
    filecounter = "counter.csv"
    file = open("counter.csv")
    type(file)
    csvreader = csv.reader(file)
    test = []
    test = next(csvreader)
    print(test[0])
    file.close()

# RETRAINING PROGRAM - JOSHUA BROWN
    if int(test[0]) % 2000 == 0 and int(test[0]) != 0:
        Global.RetrainCounter = Global.RetrainCounter + 1
        file = open('Retraining_Data.csv')
        type(file)
        csvreader = csv.reader(file)
        header = []
        header = next(csvreader)
        rows = []
        for row in csvreader:
            rows.append(row)
        file.close()

        next_output_data = [0, 0, 0, 0, 0]

        for i in rows:
            if (int(i[10]) == 1):
                next_output_data[0] += 1
                # print("1 was found: ",next_output_data[0])
            elif (int(i[10]) == 2):
                next_output_data[1] += 1
                # print("2 was found: ",next_output_data[1])
            elif (int(i[10]) == 3):
                next_output_data[2] += 1
                # print("3 was found: ",next_output_data[2])
            elif (int(i[10]) == 4):
                next_output_data[3] += 1
                # print("4 was found: ",next_output_data[3])
            elif (int(i[10]) == 5):
                next_output_data[4] += 1
                # print("5 was found: ", next_output_data[4])
        print(next_output_data)

        total_uploads = next_output_data[0] + next_output_data[1] + next_output_data[2] \
                        + next_output_data[3] + next_output_data[4]
        print("total uploads:", total_uploads)
        if ((next_output_data[0] / total_uploads) >= .5):
            print("to many priority not retraining")
        elif ((next_output_data[1] / total_uploads) >= .5):
            print("to many large mp4 not retraining")
        elif ((next_output_data[2] / total_uploads) >= .5):
            print("to many small mp4 not retraining")
        elif ((next_output_data[3] / total_uploads) >= .5):
            print("to many text not retraining")
        elif ((next_output_data[4] / total_uploads) >= .5):
            print("to many image not retraining")
        else:
            print("will retrain")
            file = open('Retraining_Data.csv')
            type(file)
            csvreader = csv.reader(file)
            header = []
            header = next(csvreader)
            rows = []
            vary = 0
            for row in csvreader:
                if vary % 2 != 0:
                    rows.append(row)
                    vary +=1
                else:
                    vary +=1
            file.close()
            data = rows
            df = pd.DataFrame(data, columns=header)
            df.fillna(-99999, inplace=True)
            # df.dropna(inplace=True)

            feature_cols = ['U_Priority', 'G_Priority', 'U_Large_MP4', 'G_Large_MP4',
                            'U_Small_MP4', 'G_Small_MP4', 'U_TXT',
                            'G_TXT', 'U_IMG', 'G_IMG']
            X = df[feature_cols]
            Y = df.Output
            x_train, x_test, y_train, y_test = model_selection.train_test_split(X, Y, test_size=.01,
                                                                                random_state=randint(0, 999))

            clf = LogisticRegression(n_jobs=-1)
            # clf = svm.SVR(kernel='linear')  # classifier created as linear regression n_jobs = -1 uses all CPUs
            # clf = LinearRegression(n_jobs=-1)

            clf.fit(x_train, y_train)  # classifier is fit using trains
            with open('testing.pickle', 'wb') as f:
                pickle.dump(clf, f)
            y_pred = clf.predict(x_test)

    else:
        val = int(test[0])
        val = val + 1
        test[0] = val
        #print(test[0])
        with open(filecounter, 'w', newline='') as csvfile:

            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(test)
            #csvwriter.writerow(Features)
       # print("Running ", val)
    print("PREDICTION: ", y_pred)
    Profile.algonum = int(y_pred[0])

    if Profile.algonum == 1:
        Profile.location = 'priority/'
    if Profile.algonum == 2:
        Profile.location = 'large_video/'
    if Profile.algonum == 3:
        Profile.location = 'video/'
    if Profile.algonum == 4:
        Profile.location = 'text/'
    if Profile.algonum == 5:
        Profile.location = 'images/'

@receiver(post_save, sender=User)
def save_profile(sender, instance, **kwargs):
    instance.profile.save()




@receiver(post_save, sender=Post)
def error_checker(sender, *args, **kwargs):
    def move_blob(bucket_name, blob_name, destination_bucket_name, destination_blob_name):
        """Moves a blob from one bucket to another with a new name."""
        # The ID of your GCS bucket
        # bucket_name = "your-bucket-name"
        # The ID of your GCS object
        # blob_name = "your-object-name"
        # The ID of the bucket to move the object to
        # destination_bucket_name = "destination-bucket-name"
        # The ID of your new GCS object (optional)
        # destination_blob_name = "destination-object-name"

        storage_client = storage.Client()

        source_bucket = storage_client.bucket(bucket_name)
        source_blob = source_bucket.blob(blob_name)
        destination_bucket = storage_client.bucket(destination_bucket_name)

        blob_copy = source_bucket.copy_blob(
            source_blob, destination_bucket, destination_blob_name
        )
        source_bucket.delete_blob(blob_name)

        print(
            "Blob {} in bucket {} moved to blob {} in bucket {}.".format(
                source_blob.name,
                source_bucket.name,
                blob_copy.name,
                destination_bucket.name,
            )
        )
    check = str(Post.objects.all().last().image)
    #print("CHECK IS THIS NOW", check)
    str(check).replace("text", "")
    #print("Profile.location is", Profile.algonum)
    Global.endtag = Post.objects.all().last().image
    client = storage.Client()
    # Create a bucket object for our bucket
    bucket = client.get_bucket('ecen403images')
    # Create a blob object from the filepath
    blob = bucket.get_blob(check)
    if Profile.algonum == 2 and (not (str(check).endswith(".mp4") or str(check).endswith(".MOV")) or (blob.size/1000000 < 10)):  # Checking if Large MP4 prediction was correct
        filename = str(check).replace("large_video", "")
        print("INCORRECTLY SAVED TO LARGE MP4")
        str(check).replace("large_video", "")
        if str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(
                ".png"):  # if it should be in images
            curcheck = str(check).replace("large_video", "images")
            move_blob("ecen403images", "large_video"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif str(check).endswith(".txt"):  # if it should be saved in txt
            curcheck = str(check).replace("large_video", "text")
            move_blob("ecen403images", "large_video"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 < 10):  # it should be in small MP4 #CHANGE THIS FOR SMALL MP4
            curcheck = str(check).replace("large_video", "video")
            move_blob("ecen403images", "large_video"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
    elif Profile.algonum == 3 and (not (str(check).endswith(".mp4") or str(check).endswith(".MOV")) or (blob.size/1000000 >= 10)):  # Checking if small MP4 prediction was correct
        filename = str(check).replace("video", "")
        print("INCORECTLY SAVED TO SMALL MP4")
        str(check).replace("video", "")
        if str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(
                ".png"):  # if it should be in images
            curcheck = str(check).replace("video", "large_video")
            move_blob("ecen403images", "video" + filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif str(check).endswith(".txt"):  # if it should be saved in txt
            curcheck = str(check).replace("video", "large_video")
            move_blob("ecen403images", "video"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 >= 10):  # if it should be in large MP4 #CHANGE THIS FOR LARGE MP4
            curcheck = str(check).replace("video", "large_video")
            print("Arrived in LARGE MP4 ")
            move_blob("ecen403images", "video"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
    elif Profile.algonum == 4 and (not str(check).endswith(".txt")):  # checking if txt prediction was correct
        filename = str(check).replace("text", "")
        print("INCORECTLY SAVED TO TEXT")
        check = str(check)
        if str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith( ".png") or str(check).endswith(".PNG"):  # if it should be in images
            curcheck = str(check).replace("text", "images")
            #print("Check is", check)
            #print("curcheck is", curcheck)
            move_blob("ecen403images", "text"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 >= 10):  # if it should be in large MP4 #CHANGE THIS FOR LARGE MP4
            curcheck = str(check).replace("text", "large_video")
            move_blob("ecen403images", "text"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 < 10):  # it should be in small MP4 #CHANGE THIS FOR SMALL MP4
            curcheck = str(check).replace("text", "video")
            move_blob("ecen403images", "text"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
    elif Profile.algonum == 5 and (not (str(check).endswith(".PNG") or str(check).endswith(".png") or str(check).endswith(".jpg") or str(check).endswith(".jpeg"))) :  # checking if image prediction was correct
        filename = str(check).replace("images", "")
        print("INCORRECTLY SAVED TO IMAGE")
        str(check).replace("images", "")
        if str(check).endswith(".txt"):  # if it should be saved in txt
            curcheck = str(check).replace("images", "text")
            print("CHECK IS", check)
            print("FILENAME IS", filename)
            move_blob("ecen403images", "images"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 >= 10):  # if it should be in large MP4  #CHANGE THIS FOR LARGE MP4
            curcheck = str(check).replace("images", "large_video")
            move_blob("ecen403images", "images"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
        elif (str(check).endswith(".mp4") or str(check).endswith(".MOV")) and (blob.size/1000000 < 10):  # it should be in small MP4 #CHANGE THIS FOR SMALL MP4
            curcheck = str(check).replace("images", "video")
            move_blob("ecen403images", "images"+filename, "ecen403images", curcheck)
            last_post = Post.objects.last()
            if last_post is not None:
                last_post.image = curcheck
                last_post.save()
    else:  # if no other prediction matches then it has to be a priority upload
        print("Run through.")










    # if (not str(check).endswith(".txt")) and Profile.algonum == 4:
    #     print("INCORRECTLY SAVED text")
    #     if str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(".png"):
    #         move_blob("ecen403images", "text/Profile_Picture.png", "ecen403images", "images/Profile_Picture.png")
    #         #shutil.move("https://storage.googleapis.com/ecen403images/text/"+str(check), "ecen403images/images/testfile.txt")
    #    # if str(check).endswith(".txt"):
    #    # if str(check).endswith(".mov") or str(check).endswith(".mp4"):
    #    # if str(check).endswith(".mov") or str(check).endswith(".mp4"):
    # if (str(check).endswith(".jpeg") or str(check).endswith(".jpg") or str(check).endswith(".png")) and Profile.algonum != 5:
    #     print("INCORRECTLY SAVED image")
    # if (str(check).endswith(".mov") or str(check).endswith(".mp4")) and Profile.algonum != 3:
    #     print("INCORRECTLY SAVED")
    # if (str(check).endswith(".mov") or str(check).endswith(".mp4")) and Profile.algonum != 2:
    #     print("INCORRECTLY SAVED")
#@receiver(post_save, sender=User)
#def file_size(sender, **kwargs): # add this to some file where you can import it from
 #   limit = 104857600
  #  if Post > limit:
   #     print("FILE IS TOO LARGE")
# This will check if the user is logged in

@receiver(user_logged_in, sender=User)
def post_login(sender, request, **kwargs):
    print("INSTANCE IS", request.user)
    profile = Profile.objects.get(user=request.user)
    gimg = Global.globalimg
    gvid = Global.globalvid
    gbvid = Global.globalbvid
    gtxt = Global.globaltext
    gprio = Global.globalprio
    array = [profile.priouploads/2, gprio, profile.bviduploads/2, gbvid, profile.viduploads/2, gvid, profile.textuploads/2,
             gtxt, profile.imguploads/2, gimg]
    #testarr = [4, 9, 7, 3, 2, 5, 6, 12, 7, 10]
    #########

    pickle_in = open('Websiteregression.pickle', 'rb')
    clf = pickle.load(pickle_in)
    # clf = LogisticRegression(n_jobs=-1)

    # clf.fit(x_train, y_train)  # classifier is fit using trains
    y_pred = clf.predict([array])

    # print('x_test: ', x_test)
    print('y_prediction: ', y_pred)
    Profile.algonum = int(y_pred[0])
    if Profile.algonum == 1:
        Profile.location = 'priority/'
    if Profile.algonum == 2:
        Profile.location = 'large_video/'
    if Profile.algonum == 3:
        Profile.location = 'video/'
    if Profile.algonum == 4:
        Profile.location = 'text/'
    if Profile.algonum == 5:
        Profile.location = 'images/'
    print(Profile.location)
    #####
