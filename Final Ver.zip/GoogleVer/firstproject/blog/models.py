from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse
from django.core.exceptions import ValidationError
from users.models import Profile
import os




def file_size(value):  # add this to some file where you can import it from
    # Limit is set to 20 MB per upload
    limit = 20971520
    if value.size > limit:
        print("FILE IS TOO LARGE")
        raise ValidationError('File too large. Size should not exceed 2 MiB.')


# Create your models here.
#curProfile =Profile.objects.all().last().location




def create_path(instance, filename):
    #curUser = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='+')
    #print("Curuser: ", curUser.name)
    user = User.objects.get(username = instance.author.username)
    profile = Profile.objects.get(user=user)
    if instance.Priority_Upload == True:
        profile.location = 'priority/'
    return os.path.join(
        str(profile.location),
        filename
    )

class Post(models.Model):

    #profile = models.ForeignKey(Profile, on_delete=models.CASCADE,  related_name='+')
    title = models.CharField(max_length=100)
    Priority_Upload = models.BooleanField(default='priority', blank=True, null=True)
    #content = models.FileField(default='text', upload_to=create_path, blank=True, null=True)
    image = models.FileField(default='default', upload_to=create_path, blank=True, null=True, validators=[file_size])
    #video = models.FileField(default='video', upload_to=create_path, blank=True, null=True)
    #large_video = models.FileField(default='large_video', upload_to=create_path, blank=True, null=True)
    date_posted = models.DateTimeField(default=timezone.now)
    # user owns the post, but post doesn't own the user.
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='+')
    #imagesize = os.path.getsize('images/CleaversEdge.png')
    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})
