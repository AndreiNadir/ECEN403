from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse
from django.core.exceptions import ValidationError

def file_size(value): # add this to some file where you can import it from
    limit = 104857600
    if value.size > limit:
        print("FILE IS TOO LARGE")
        raise ValidationError('File too large. Size should not exceed 2 MiB.')
# Create your models here.
class Post(models.Model):
    Priority_Upload = models.FileField(default='priority', upload_to='priority/', blank=True, null=True)
    title = models.CharField(max_length=100)
    content = models.FileField(default='text', upload_to='text/', blank=True, null=True)
    image = models.ImageField(default='default', upload_to='images/', blank=True, null=True)
    video = models.FileField(default='video', upload_to='videos/',blank=True, null=True)



    date_posted = models.DateTimeField(default=timezone.now)
    # user owns the post, but post doesn't own the user.
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='+')
    def __str__(self):
        return self.title
    def get_absolute_url(self):
        return reverse('post-detail', kwargs={'pk': self.pk})

