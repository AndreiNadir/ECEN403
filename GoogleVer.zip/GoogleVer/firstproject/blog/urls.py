from django.urls import path
from . import views
from .views import *
urlpatterns = [
    #Path sets up a path command. First argument is the tag its looking for.
    #second argument is where it goes to get the http code, and 3rd is name
    path('', views.landing, name='Project-home'),
    path('post/<int:pk>/', views.PostDetailView.as_view(), name='post-detail'),
    path('post/new/', PostCreateView.as_view(), name= 'post-create'),
    path('post/<int:pk>/update/', PostUpdateView.as_view(), name='post-update'),
    path('post/<int:pk>/delete/', PostDeleteView.as_view(), name='post-delete'),
    path('profile', views.PostListView.as_view(), name='Project-home'),
    path('post/<int:pk>/download', views.downloadFile.as_view(), name='download-file'),
    path('landing/', views.landing, name='landing')
]

